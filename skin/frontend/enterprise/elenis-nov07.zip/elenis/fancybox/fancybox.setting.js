jQuery(document).ready(function() {
			jQuery("a[rel=image_gallery]").fancybox({
				'transitionIn'		: 'elastic',
				'transitionOut'		: 'elastic'
			});
		});