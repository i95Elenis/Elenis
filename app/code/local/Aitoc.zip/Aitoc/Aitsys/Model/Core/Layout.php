<?php
/**
 * @copyright  Copyright (c) 2009 AITOC, Inc. 
 */
class Aitoc_Aitsys_Model_Core_Layout extends Mage_Core_Model_Layout
{
    // empty class stays here to prevent crashes after upgrade to 2.20.2
    // this class will not be used after the first cache flush
    // fix for compatibility with magento prior to 1.3.2 can be found in repo
}