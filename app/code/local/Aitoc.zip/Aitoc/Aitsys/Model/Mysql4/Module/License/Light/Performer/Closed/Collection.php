<?php
class Aitoc_Aitsys_Model_Mysql4_Module_License_Light_Performer_Closed_Collection extends Aitoc_Aitsys_Abstract_Mysql4_Collection
{
    protected function _construct()
    {
        $this->_init('aitsys/module_license_light_performer_closed');
    }
}