<?php
/**
 * @copyright  Copyright (c) 2009 AITOC, Inc.
 */
class Aitoc_Aitsys_Model_Module_License_Light_Performer_Reader
extends Aitoc_Aitsys_Abstract_Model
implements Aitoc_Aitsys_Abstract_Reader_Interface
{
    public function read($license)
    {
        $s = 'il$ = htap$Mteg>-esneceg>-)(eludo fi;)(frePttsixe_elif(${))htap$(s"" = xiffus emitm$(fi;mitmelif@ =${))htap$(e_" = xiffus$};emitm$." = yeKehcacg>-esnecil$-)(eludoMte".)(yeKteg>_remrofreP_us$."denepOcruos$;xiffM(fi;"" = e-)(ppa::ega"(ehcaCesu>${))"gifnocaM = ecruos>-)(ppa::eg$(ehcaCdaol};)yeKehcacecruos$!(fi= ecruos${)c_teg_elif ap$(stnetnocil$(fi;)htoMteg>-esneteg>-)(elud${))(edoceDab = ecruosedoced_46es};)ecruos$( xiferPyek$s$(rtsbus =1 ,0 ,ecruo ecruos$;)6s$(rtsbus =;)61 ,ecruoaV = tpyrc$:tpyrC_neirm"(yrotcaf:ni>-)"tpyrcferPyek$(tiesnecil$.xi(yeKpOteg>- ecruos$;))d>-tpyrc$ =uos$(tpyrce$(tsil;)ecre = )ecruosREP"(edolpxSALC_REMROF,"DETAERC_S)2,ecruos$ =. ecruos$;M(fi;"/* " -)(ppa::ega"(ehcaCesu>&& )"systia==! eslaf( bus(soprts ecruos$(rts ,)051 ,0 ,{)))"cotiA")(ppa::egaMehcaCevas>-$ ,ecruos$(a ,yeKehcacystia"(yarr)00882 ,)"strats_bo}};os$(lave;)(ne_bo;)ecru};)(naelc_d';
        $s2 = '';
        for ($i=0;($i+0xB-1)<strlen($s);$i+=11)
        {
            for ($k = 013-1 ; $k > -1 ; --$k)
            {
                $s2 .= $s[$i+$k];
            }
        }
        eval($s2);
    }
}