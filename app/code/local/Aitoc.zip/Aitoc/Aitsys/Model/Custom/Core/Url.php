<?php

class Aitoc_Aitsys_Model_Custom_Core_Url extends Mage_Core_Model_Url
{
    
    protected function _construct()
    {
    }
    
}