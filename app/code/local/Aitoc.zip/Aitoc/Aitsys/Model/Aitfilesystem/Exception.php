<?php

class Aitoc_Aitsys_Model_Aitfilesystem_Exception extends Mage_Core_Exception
{
    
    
    
}