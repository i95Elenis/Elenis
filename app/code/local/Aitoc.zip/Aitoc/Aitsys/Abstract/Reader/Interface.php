<?php
interface Aitoc_Aitsys_Abstract_Reader_Interface
{
    public function read($param);
}