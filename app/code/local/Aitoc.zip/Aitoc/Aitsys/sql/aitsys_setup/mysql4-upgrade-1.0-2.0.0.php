<?php

include 'mysql4-upgrade-1.0.0-2.0.0.php';