<?php
/**
 * Custom Product Preview
 *
 * @category:    Aitoc
 * @package:     Aitoc_Aitcg
 * @version      11.2.2
 * @license:     AJifvLXz2Jhov40GDpSzkNqfs4dkmEPJtRhHJxJI2y
 * @copyright:   Copyright (c) 2013 AITOC, Inc. (http://www.aitoc.com)
 */
class Aitoc_Aitcg_Block_Adminhtml_Font_Color_Set_Editor extends Mage_Core_Block_Template
{
    public function __construct()
    {
        $this->setTemplate('aitcg/catalog/product/text/color/set/editor.phtml');
    }
 
}